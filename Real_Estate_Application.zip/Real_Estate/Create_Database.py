import Connect_With_Database as conn

def Create_Database():
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()
    Mycursor.execute("CREATE DATABASE IF NOT EXISTS Real_Estate_DB")
    Mycursor.execute("USE Real_Estate_DB")
    print("Database created successfully")
    Mycursor.close()
    connect.close()

def Create_Table():
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()
    
    # ✅ Credentials table
    Mycursor.execute("""
        CREATE TABLE IF NOT EXISTS Credentials (
            id INT AUTO_INCREMENT PRIMARY KEY,
            first_name VARCHAR(50) NOT NULL,
            last_name VARCHAR(50) NOT NULL,
            username VARCHAR(50) NOT NULL,
            email VARCHAR(50) NOT NULL,
            password VARCHAR(50) NOT NULL,
            account_type ENUM('Buyer', 'Seller') NOT NULL
        )
    """)

    # ✅ Sessional_id table with foreign key to Credentials
    Mycursor.execute("""
        CREATE TABLE IF NOT EXISTS Sessional_id (
            id VARCHAR(255) PRIMARY KEY,
            C_id INT,
            FOREIGN KEY (C_id) REFERENCES Credentials(id)
        )
    """)

    # ✅ Seller table with foreign key to Sessional_id
    Mycursor.execute("""
        CREATE TABLE IF NOT EXISTS Seller (
            ID INT AUTO_INCREMENT PRIMARY KEY,
            Property_Type VARCHAR(50),
            Phone_Number VARCHAR(15),
            Email VARCHAR(50),
            Location VARCHAR(100),
            Price DECIMAL(10, 2),
            Description LONGTEXT,
            Image LONGBLOB,
            Date_Added TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            Status ENUM('Available', 'Sold') DEFAULT 'Available',  -- Add Status column
            Sessional_id VARCHAR(255),
            FOREIGN KEY (Sessional_id) REFERENCES Sessional_id(id)
        )
    """)

    # ✅ Buyer table with foreign key to Sessional_id
    Mycursor.execute("""
        CREATE TABLE IF NOT EXISTS Buyer (
            ID INT AUTO_INCREMENT PRIMARY KEY,
            Phone_Number VARCHAR(15),
            Email VARCHAR(50),
            Location VARCHAR(100),
            Sessional_id VARCHAR(255),
            FOREIGN KEY (Sessional_id) REFERENCES Sessional_id(id)
        )
    """)

    # ✅ Payment table with foreign key to Buyer and Seller
    Mycursor.execute("""
        CREATE TABLE IF NOT EXISTS Payment (
            ID INT AUTO_INCREMENT PRIMARY KEY,
            Buyer_ID INT,
            Seller_ID INT,
            Amount DECIMAL(10, 2) NOT NULL,
            Payment_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            Payment_Method ENUM('Credit Card', 'Debit Card', 'Net Banking', 'UPI', 'Cash') NOT NULL,
            FOREIGN KEY (Buyer_ID) REFERENCES Buyer(ID),
            FOREIGN KEY (Seller_ID) REFERENCES Seller(ID)
        )
    """)

    # ✅ Transaction table with foreign key to Payment
    Mycursor.execute("""
        CREATE TABLE IF NOT EXISTS Transaction (
            ID INT AUTO_INCREMENT PRIMARY KEY,
            Payment_ID INT,
            Transaction_Status ENUM('Pending', 'Completed', 'Failed') NOT NULL,
            Transaction_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (Payment_ID) REFERENCES Payment(ID)
        )
    """)

    print("Tables created successfully")
    Mycursor.close()
    connect.close()

# Run the functions
# Create_Database()
# Create_Table()