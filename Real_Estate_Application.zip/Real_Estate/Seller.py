import tkinter as tk
from tkinter import messagebox, filedialog
import Insert  # Your DB interaction module
import Login_SignUp  # Your login/signup module

def Seller_UI(root, seller_id):
    """Display the Seller interface."""

    def add_property():
        """Add a new property with vertical and horizontal scroll support."""
        for widget in main_frame.winfo_children():
            widget.destroy()

        # --- Scrollable frame setup with both scrollbars ---
        canvas = tk.Canvas(main_frame, height=500)
        v_scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        h_scrollbar = tk.Scrollbar(main_frame, orient="horizontal", command=canvas.xview)
        scrollable_frame = tk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(
                scrollregion=canvas.bbox("all")
            )
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        v_scrollbar.pack(side="right", fill="y")
        h_scrollbar.pack(side="bottom", fill="x")

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        def _on_shift_mousewheel(event):
            canvas.xview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        canvas.bind_all("<Shift-MouseWheel>", _on_shift_mousewheel)

        # --- Add form widgets to scrollable_frame instead of main_frame ---
        tk.Label(scrollable_frame, text="Add Property", font=("Arial", 20, "bold")).pack(pady=20)

        tk.Label(scrollable_frame, text="Property Type").pack(pady=5)
        entry_property_type = tk.Entry(scrollable_frame)
        entry_property_type.pack(pady=5)

        tk.Label(scrollable_frame, text="Phone Number").pack(pady=5)
        entry_phone_number = tk.Entry(scrollable_frame)
        entry_phone_number.pack(pady=5)

        tk.Label(scrollable_frame, text="Email").pack(pady=5)
        entry_email = tk.Entry(scrollable_frame)
        entry_email.pack(pady=5)

        tk.Label(scrollable_frame, text="Location").pack(pady=5)
        entry_location = tk.Entry(scrollable_frame)
        entry_location.pack(pady=5)

        tk.Label(scrollable_frame, text="Price").pack(pady=5)
        entry_price = tk.Entry(scrollable_frame)
        entry_price.pack(pady=5)

        tk.Label(scrollable_frame, text="Description").pack(pady=5)
        entry_description = tk.Text(scrollable_frame, height=5, width=40)
        entry_description.pack(pady=5)

        tk.Label(scrollable_frame, text="Image Path").pack(pady=5)
        entry_image_path = tk.Entry(scrollable_frame)
        entry_image_path.pack(pady=5)

        tk.Button(scrollable_frame, text="Browse", command=lambda: browse_image(entry_image_path)).pack(pady=5)

        def submit_property():
            property_type = entry_property_type.get().strip()
            phone_number = entry_phone_number.get().strip()
            email = entry_email.get().strip()
            location = entry_location.get().strip()
            price = entry_price.get().strip()
            description = entry_description.get("1.0", tk.END).strip()
            image_path = entry_image_path.get().strip()

            if not all([property_type, phone_number, email, location, price, description, image_path]):
                messagebox.showerror("Error", "All fields are required!")
                return

            try:
                with open(image_path, "rb") as file:
                    image_data = file.read()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to read image: {e}")
                return

            try:
                Insert.Insert_Real_Estate(
                    Property_Type=property_type,
                    Phone_Number=phone_number,
                    Email=email,
                    Location=location,
                    Price=price,
                    Description=description,
                    Image=image_data,
                    Sessional_id=seller_id
                )
                messagebox.showinfo("Success", "Property added successfully!")
                view_properties()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add property: {e}")

        tk.Button(scrollable_frame, text="Submit", command=submit_property).pack(pady=10)
        tk.Button(scrollable_frame, text="Back", command=view_properties).pack(pady=10)

    def view_properties():
        """View all properties listed by the seller."""
        for widget in main_frame.winfo_children():
            widget.destroy()

        tk.Label(main_frame, text="Your Properties", font=("Arial", 20, "bold")).pack(pady=20)

        properties = Insert.get_properties_by_seller(seller_id)

        if not properties:
            tk.Label(main_frame, text="No properties listed yet.", font=("Arial", 14)).pack(pady=10)
            tk.Button(main_frame, text="Add Property", command=add_property).pack(pady=10)
            def logout():
             Login_SignUp.logout_(root, main_frame)
            # Add the Logout button
            logout_btn = tk.Button(main_frame, text="Logout", command=logout, width=15)
            logout_btn.pack(pady=10)
            return

        # Scrollable frame setup
        canvas = tk.Canvas(main_frame, height=500)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        for property in properties:
            outer_frame = tk.Frame(scrollable_frame)
            outer_frame.pack(pady=10, padx=10, fill="x")

            property_frame = tk.Frame(outer_frame, bd=2, relief="solid", padx=20, pady=10)
            property_frame.pack(expand=True, fill="x")

            tk.Label(property_frame, text=f"🏡 Property Type: {property['Property_Type']}", font=("Arial", 12)).pack(anchor="center", pady=2)
            tk.Label(property_frame, text=f"📍 Location: {property['Location']}", font=("Arial", 12)).pack(anchor="center", pady=2)
            tk.Label(property_frame, text=f"💰 Price: ${property['Price']}", font=("Arial", 12)).pack(anchor="center", pady=2)
            tk.Label(property_frame, text=f"📝 Description:\n{property['Description']}", font=("Arial", 12), wraplength=400, justify="center").pack(anchor="center", pady=2)
            tk.Label(property_frame, text=f"📌 Status: {property['Status']}", font=("Arial", 12, "bold")).pack(anchor="center", pady=2)

            btn_frame = tk.Frame(property_frame)
            btn_frame.pack(pady=5)

            tk.Button(btn_frame, text="Update Status", command=lambda p=property: update_status(p)).pack(side="left", padx=10)
            tk.Button(btn_frame, text="Delete", command=lambda p=property: delete_property(p)).pack(side="left", padx=10)

        # amount = Insert.get_Amount()
        amount_block(main_frame, Login_SignUp.amount)

        tk.Button(main_frame, text="➕ Add New Property", font=("Arial", 12), command=add_property).pack(pady=20)

        def logout():
           Login_SignUp.logout_(root, main_frame)
        # Add the Logout button
        logout_btn = tk.Button(main_frame, text="Logout", command=logout, width=15)
        logout_btn.pack(pady=10)

    def update_status(property):
        new_status = "Sold" if property["Status"] == "Available" else "Available"
        confirm = messagebox.askyesno("Confirm Update", f"Are you sure you want to mark this property as {new_status}?")
        if confirm:
            try:
                Insert.update_property_status(property["ID"], new_status)
                messagebox.showinfo("Success", f"Property status updated to {new_status}!")
                view_properties()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update property status: {e}")

    def delete_property(property):
        confirm = messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete the property '{property['Property_Type']}'?")
        if confirm:
            try:
                Insert.delete_property(property["ID"])
                messagebox.showinfo("Success", "Property deleted successfully!")
                view_properties()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete property: {e}")

    def browse_image(entry):
        file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
        if file_path:
            entry.delete(0, tk.END)
            entry.insert(0, file_path)

    # Clear root and create main frame
    for widget in root.winfo_children():
        widget.destroy()

    main_frame = tk.Frame(root)
    main_frame.pack(fill="both", expand=True)

    # Show properties on start
    view_properties()

def amount_block(root, amount):
    """Display a block with the total amount."""
    block = tk.Frame(root, bg="#e0f7fa", bd=2, relief="groove")
    block.pack(pady=40, padx=20, fill="x")

    tk.Label(block, text="Total Amount", bg="#e0f7fa", fg="#00796b",
             font=("Arial", 14, "bold")).pack(pady=(10, 0))
    tk.Label(block, text=f"Rs. {amount:,}", bg="#e0f7fa", fg="#004d40",
             font=("Arial", 18, "bold")).pack(pady=(5, 10))