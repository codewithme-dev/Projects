import Insert
import Buyer
import Seller
import pyttsx3
import tkinter as tk
from tkinter import messagebox

def speak(text):
    """Speak the given text using pyttsx3."""
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

def SignUp(root, main_frame):
    """Display the Sign-Up form and handle user registration."""
    def submit_signup():
        first_name = entry_first_name.get()
        last_name = entry_last_name.get()
        username = entry_username.get()
        email = entry_email.get()
        password = entry_password.get()
        account_type = account_type_var.get()  # Get the selected account type (Buyer or Seller)

        # Validate user input
        existing_user = Insert.Existing_User(username, email)

        if existing_user:
            speak("Username or Email already exists. Please try again.")
            messagebox.showerror("Error", "Username or Email already exists. Please try again.")
            return

        if not first_name or not last_name:
            speak("First Name and Last Name are required fields.")
            messagebox.showerror("Error", "First Name and Last Name are required fields.")
            return
        if email.count('@') != 1 or email.count('.') < 1:
            speak("Invalid email format.")
            messagebox.showerror("Error", "Invalid email format.")
            return
        if len(password) < 8:
            speak("Password must be at least 8 characters long.")
            messagebox.showerror("Error", "Password must be at least 8 characters long.")
            return
        if not any(char.isdigit() for char in password):
            speak("Password must contain at least one digit.")
            messagebox.showerror("Error", "Password must contain at least one digit.")
            return
        if not any(char.isalpha() for char in password):
            speak("Password must contain at least one letter.")
            messagebox.showerror("Error", "Password must contain at least one letter.")
            return
        if not any(char in "!@#$%^&*()-_+=<>?{}[]|:;\"'`~" for char in password):
            speak("Password must contain at least one special character.")
            messagebox.showerror("Error", "Password must contain at least one special character.")
            return
        if len(password) > 20:
            speak("Password must not exceed 20 characters.")
            messagebox.showerror("Error", "Password must not exceed 20 characters.")
            return
        if not account_type:
            speak("Please select an account type.")
            messagebox.showerror("Error", "Please select an account type.")
            return

        # Insert credentials into the database
        Insert.Insert_Credentials(first_name, last_name, username, email, password, account_type)

        speak("Sign-up successfully!")
        messagebox.showinfo("Success", "Sign-up successfully!")
        show_main_menu(root, main_frame)

    # Hide the main frame and display the sign-up form
    for widget in main_frame.winfo_children():
        widget.pack_forget()

    tk.Label(main_frame, text="First Name").pack(pady=5)
    entry_first_name = tk.Entry(main_frame)
    entry_first_name.pack(pady=5)

    tk.Label(main_frame, text="Last Name").pack(pady=5)
    entry_last_name = tk.Entry(main_frame)
    entry_last_name.pack(pady=5)

    tk.Label(main_frame, text="Username").pack(pady=5)
    entry_username = tk.Entry(main_frame)
    entry_username.pack(pady=5)

    tk.Label(main_frame, text="Email").pack(pady=5)
    entry_email = tk.Entry(main_frame)
    entry_email.pack(pady=5)

    tk.Label(main_frame, text="Password").pack(pady=5)
    entry_password = tk.Entry(main_frame, show="*")
    entry_password.pack(pady=5)

    # Account type selection
    tk.Label(main_frame, text="Select Account Type").pack(pady=5)
    account_type_var = tk.StringVar(value="")  # Variable to store the selected account type
    tk.Radiobutton(main_frame, text="Buyer", variable=account_type_var, value="Buyer").pack(pady=2)
    tk.Radiobutton(main_frame, text="Seller", variable=account_type_var, value="Seller").pack(pady=2)

    tk.Button(main_frame, text="Submit", command=submit_signup).pack(pady=10)
    tk.Button(main_frame, text="Back", command=lambda: show_main_menu(root, main_frame)).pack(pady=10)

    # Speak after displaying the form
    speak("Welcome to the Sign-Up page")

def Login(root, main_frame, after_login):
    """Display the Login form and handle user authentication."""
    def submit_login():
        username = entry_username.get()
        password = entry_password.get()
        global amount
        amount = Insert.get_seller_total_payment(username)  # Fetch total payment for the seller

        # Validate login credentials
        if Insert.login_validation(username, password):
            speak("Login successfully!")
            messagebox.showinfo("Success", "Login successfully!")
            after_login(root, username)  # Pass root and username to after_login
        else:
            speak("Invalid username or password!")
            messagebox.showerror("Error", "Invalid username or password!")

    # Hide the main frame and display the login form
    for widget in main_frame.winfo_children():
        widget.pack_forget()

    tk.Label(main_frame, text="Username").pack(pady=5)
    entry_username = tk.Entry(main_frame)
    entry_username.pack(pady=5)

    tk.Label(main_frame, text="Password").pack(pady=5)
    entry_password = tk.Entry(main_frame, show="*")
    entry_password.pack(pady=5)

    tk.Button(main_frame, text="Submit", command=submit_login).pack(pady=10)
    tk.Button(main_frame, text="Back", command=lambda: show_main_menu(root, main_frame)).pack(pady=10)

    # Speak after displaying the form
    speak("Welcome to the Login page")

def show_main_menu(root, main_frame):
    """Display the main menu with Sign-Up and Login options."""
    # Clear the main frame and display the main menu
    for widget in main_frame.winfo_children():
        widget.pack_forget()

    tk.Button(main_frame, text="Sign Up", command=lambda: SignUp(root, main_frame), width=15).pack(pady=10)
    tk.Button(main_frame, text="Login", command=lambda: Login(root, main_frame, after_login), width=15).pack(pady=10)

def after_login(root, username):
    """Handle actions after a successful login."""
    account_type = Insert.get_account_type(username)  # Fetch account type from the database
    if account_type == "Buyer":
        Buyer.Buyer_UI(root, username)  # Show Buyer UI if account type is Buyer
    elif account_type == "Seller":
        seller_id = Insert.get_seller_id(username)  # Fetch seller ID from the database
        if seller_id:
            Seller.Seller_UI(root, seller_id)  # Show Seller UI if account type is Seller
        else:
            messagebox.showerror("Error", "Seller ID not found. Please contact support.")
    else:
        messagebox.showinfo("Info", "Invalid account type. Please contact support.")

def logout_(root, main_frame):
    """Handle user logout and return to the main menu."""
    for widget in main_frame.winfo_children():
        widget.pack_forget()
    show_main_menu(root, main_frame)