import tkinter as tk
from tkinter import messagebox, simpledialog
from PIL import Image, ImageTk
import Insert  # Replace with your actual database interaction file
import io
import Login_SignUp

def Buyer_UI(root, username):
    def load_properties():
        """Load and display available properties for buyers."""
        for widget in main_frame.winfo_children():
            widget.destroy()

        properties = Insert.get_available_properties()

        if not properties:
            tk.Label(main_frame, text="No properties available.", font=("Arial", 16)).pack(pady=20)
            def logout():
                Login_SignUp.logout_(root, main_frame)

            # Add the Logout button
            logout_btn = tk.Button(main_frame, text="Logout", command=logout, width=15)
            logout_btn.pack(pady=10)
            return
        else:
            def logout():
                Login_SignUp.logout_(root, main_frame)

            # Add the Logout button
            logout_btn = tk.Button(main_frame, text="Logout", command=logout, width=15)
            logout_btn.pack(pady=10)

        for property in properties:
            property_frame = tk.Frame(main_frame, bd=2, relief="groove", padx=10, pady=10)
            property_frame.pack(fill="x", pady=10)

            if property["image"]:
                try:
                    image_data = property["image"]
                    image = Image.open(io.BytesIO(image_data))
                    image = image.resize((150, 150))
                    photo = ImageTk.PhotoImage(image)
                    img_label = tk.Label(property_frame, image=photo)
                    img_label.image = photo
                    img_label.pack(side="left", padx=10)
                    img_label.bind("<Button-1>", lambda e, p=property: show_property_details(p))
                except Exception as e:
                    tk.Label(property_frame, text="Image not available", font=("Arial", 12)).pack(side="left", padx=10)

            details_frame = tk.Frame(property_frame)
            details_frame.pack(side="left", fill="both", expand=True)

            tk.Label(details_frame, text=f"Property Type: {property['type']}", font=("Arial", 12)).pack(anchor="w")
            tk.Label(details_frame, text=f"Phone Number: {property['phone_number']}", font=("Arial", 12)).pack(anchor="w")
            tk.Label(details_frame, text=f"Email: {property['email']}", font=("Arial", 12)).pack(anchor="w")
            tk.Label(details_frame, text=f"Location: {property['location']}", font=("Arial", 12)).pack(anchor="w")
            tk.Label(details_frame, text=f"Price: ${property['price']}", font=("Arial", 12)).pack(anchor="w")
            tk.Label(details_frame, text=f"Status: {property['status']}", font=("Arial", 12)).pack(anchor="w")
            tk.Label(details_frame, text=f"Description: {property['description']}", font=("Arial", 12), wraplength=400).pack(anchor="w")

            # def logout():
            #     Login_SignUp.logout_(root, main_frame)

            # # Add the Logout button
            # logout_btn = tk.Button(main_frame, text="Logout", command=logout, width=15)
            # logout_btn.pack(pady=10)

    def show_property_details(property):
        for widget in main_frame.winfo_children():
            widget.destroy()

        tk.Label(main_frame, text="Property Details", font=("Arial", 20, "bold")).pack(pady=10)

        if property["image"]:
            try:
                image_data = property["image"]
                image = Image.open(io.BytesIO(image_data))
                image = image.resize((300, 300))
                photo = ImageTk.PhotoImage(image)
                tk.Label(main_frame, image=photo).pack(pady=10)
                main_frame.image = photo
            except Exception as e:
                tk.Label(main_frame, text="Image not available", font=("Arial", 12)).pack(pady=10)

        tk.Label(main_frame, text=f"Property Type: {property['type']}", font=("Arial", 14)).pack(anchor="w", pady=5)
        tk.Label(main_frame, text=f"Phone Number: {property['phone_number']}", font=("Arial", 14)).pack(anchor="w", pady=5)
        tk.Label(main_frame, text=f"Email: {property['email']}", font=("Arial", 14)).pack(anchor="w", pady=5)
        tk.Label(main_frame, text=f"Location: {property['location']}", font=("Arial", 14)).pack(anchor="w", pady=5)
        tk.Label(main_frame, text=f"Price: ${property['price']}", font=("Arial", 14)).pack(anchor="w", pady=5)
        tk.Label(main_frame, text=f"Status: {property['status']}", font=("Arial", 14)).pack(anchor="w", pady=5)
        tk.Label(main_frame, text=f"Description: {property['description']}", font=("Arial", 14), wraplength=500).pack(anchor="w", pady=5)

        if property["status"] == "Available":
            tk.Button(main_frame, text="Buy Now", command=lambda: perform_payment(property)).pack(pady=10)
        tk.Button(main_frame, text="Back", command=load_properties).pack(pady=10)

    def perform_payment(property):
        buyer_id = Insert.get_current_buyer_id(username)
        # If buyer_id is not found, prompt for details and create the buyer entry
        if not buyer_id:
            messagebox.showinfo("Info", "Your account is not fully set up. Please enter your details.")
            buyer_details = get_buyer_details()
            if not buyer_details:
                return
            buyer_id = Insert.add_buyer_details(username, **buyer_details)
            if not buyer_id:
                messagebox.showerror("Error", "Failed to save buyer details. Please try again.")
                return

        seller_sessional_id = property["seller_id"]
        seller_id = Insert.get_seller_id_from_sessional_id(seller_sessional_id)
        if not seller_id:
            messagebox.showerror("Error", "Seller ID not found. Please ensure the property is valid.")
            return

        amount = property["price"]

        payment_method = simpledialog.askstring(
            "Payment Method",
            "Enter payment method (Credit Card, Debit Card, UPI):"
        )
        if not payment_method:
            messagebox.showerror("Error", "Payment method is required!")
            return

        valid_methods = ["Credit Card", "Debit Card", "UPI"]
        if payment_method not in valid_methods:
            messagebox.showerror("Error", f"Invalid payment method! Choose from {', '.join(valid_methods)}.")
            return

        payment_id = Insert.add_payment(buyer_id, seller_id, amount, payment_method)
        if payment_id:
            transaction_status = "Completed" if messagebox.askyesno(
                "Transaction", "Simulate successful transaction?"
            ) else "Failed"
            Insert.add_transaction(payment_id, transaction_status)

            if transaction_status == "Completed":
                Insert.update_property_status(property["id"], "Sold")
                messagebox.showinfo("Success", "Payment successful! Transaction completed.")
                load_properties()
            else:
                messagebox.showerror("Error", "Transaction failed! Please try again.")
        else:
            messagebox.showerror("Error", "Payment failed! Please try again.")

    def get_buyer_details():
        details_window = tk.Toplevel()
        details_window.title("Enter Buyer Details")
        details_window.geometry("300x300")

        tk.Label(details_window, text="Phone Number").pack(pady=5)
        entry_phone = tk.Entry(details_window)
        entry_phone.pack(pady=5)

        tk.Label(details_window, text="Email").pack(pady=5)
        entry_email = tk.Entry(details_window)
        entry_email.pack(pady=5)

        tk.Label(details_window, text="Location").pack(pady=5)
        entry_location = tk.Entry(details_window)
        entry_location.pack(pady=5)

        buyer_details = {}

        def submit_details():
            phone = entry_phone.get()
            email = entry_email.get()
            location = entry_location.get()
            if not phone or not email or not location:
                messagebox.showerror("Error", "All fields are required!")
                return
            buyer_details["phone"] = phone
            buyer_details["email"] = email
            buyer_details["location"] = location
            details_window.destroy()

        tk.Button(details_window, text="Submit", command=submit_details).pack(pady=10)
        tk.Button(details_window, text="Cancel", command=details_window.destroy).pack(pady=10)
        details_window.wait_window()
        return buyer_details if buyer_details else None

    # Clear the root window
    for widget in root.winfo_children():
        widget.destroy()

    # --- SCROLLABLE FRAME SETUP ---
    canvas = tk.Canvas(root)
    scrollbar = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    def _on_mousewheel(event):
        canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    canvas.bind_all("<MouseWheel>", _on_mousewheel)

    # Use scrollable_frame as main_frame
    main_frame = scrollable_frame

    # Title
    tk.Label(main_frame, text="Available Properties", font=("Arial", 20, "bold")).pack(pady=10)

    # Load Properties
    load_properties()
